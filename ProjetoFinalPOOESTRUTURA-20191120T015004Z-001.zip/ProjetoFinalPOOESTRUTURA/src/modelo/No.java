package modelo;

public class No {
	
	private No proximo;
	private Paciente pac;
	
	public No() {
		// TODO Auto-generated constructor stub
	}

	public No getProximo() {
		return proximo;
	}

	public void setProximo(No proximo) {
		this.proximo = proximo;
	}

	public Paciente getPac() {
		return pac;
	}

	public void setPac(Paciente pac) {
		this.pac = pac;
	}

}
