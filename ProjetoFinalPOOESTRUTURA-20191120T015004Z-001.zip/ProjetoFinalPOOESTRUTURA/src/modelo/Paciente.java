package modelo;

import java.util.Date;

public class Paciente {
	private String cpf;
	private Date nascimento;
	private String nome;

	public Paciente(String cpf, /*Date nascimento,*/ String nome) {
		super();
		this.cpf = cpf;
		//this.nascimento = nascimento;
		this.nome = nome;
	}

	public Paciente() {

	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public Date getNascimento() {
		return nascimento;
	}

	public void setNascimento(Date nascimento) {
		this.nascimento = nascimento;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

}
