package controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import dao.PacienteDao;
import modelo.Paciente;
import vis�o.TelaPrincipal;

public class PacienteControle implements ActionListener{
	private Paciente pa;
	private TelaPrincipal tp;
	private PacienteDao dao;
	
	public PacienteControle(Paciente pa, TelaPrincipal tp){
		this.pa = pa;
		this.tp = tp;
		this.tp.getMntmCadastrarNovoPaciente().addActionListener(this);
		dao = new PacienteDao();
	}
	
	
	@Override	
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getActionCommand().equals("menuCad")){
			this.tp.setContentPane(this.tp.getTcad());
			this.tp.revalidate();
			this.tp.repaint();
		}
		
		if(e.getActionCommand().equals("Cadastar")){
			
			String nome = this.tp.getTcad().getTextFieldnome().getText();
			String cpf = this.tp.getTcad().getTextFieldcpf().getText();
			
			pa = new Paciente(cpf, nome);
			
			dao.cadastrarPaciente(pa);
			
		}
	}
	
}
