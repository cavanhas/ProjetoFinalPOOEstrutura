package vis�o;

import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

public class TelaCadastro extends JPanel {
	private JTextField textFieldcpf;
	private JTextField textFieldnome;
	private JTextField textField;
	private JButton btnCadastrar;
	private JButton btnLimpar;

	public TelaCadastro() {
		setLayout(new MigLayout("", "[][grow][][][grow][][][]", "[][][][][]"));

		JLabel lblCadastro = new JLabel("Cadastro");
		add(lblCadastro, "cell 2 0");

		JLabel lblCpf = new JLabel("CPF:");
		add(lblCpf, "cell 0 1,alignx left");

		textFieldcpf = new JTextField();
		add(textFieldcpf, "cell 1 1,growx");
		textFieldcpf.setColumns(10);

		JLabel lblNome = new JLabel("Nome:");
		add(lblNome, "cell 3 1,alignx trailing");

		textFieldnome = new JTextField();
		add(textFieldnome, "cell 4 1,growx");
		textFieldnome.setColumns(10);

		JLabel lblEndereo = new JLabel("Endere\u00E7o:");
		add(lblEndereo, "cell 0 2,alignx left");

		textField = new JTextField();
		textField.setText("");
		add(textField, "cell 1 2,growx");
		textField.setColumns(10);

		btnCadastrar = new JButton("Cadastrar");
		add(btnCadastrar, "cell 0 4");

		btnLimpar = new JButton("Limpar");
		add(btnLimpar, "cell 1 4");

	}

	public JTextField getTextFieldcpf() {
		return textFieldcpf;
	}

	public void setTextFieldcpf(JTextField textFieldcpf) {
		this.textFieldcpf = textFieldcpf;
	}

	public JTextField getTextFieldnome() {
		return textFieldnome;
	}

	public void setTextFieldnome(JTextField textFieldnome) {
		this.textFieldnome = textFieldnome;
	}

	public JTextField getTextField() {
		return textField;
	}

	public void setTextField(JTextField textField) {
		this.textField = textField;
	}

	public JButton getBtnCadastrar() {
		return btnCadastrar;
	}

	public void setBtnCadastrar(JButton btnCadastrar) {
		this.btnCadastrar = btnCadastrar;
	}

	public JButton getBtnLimpar() {
		return btnLimpar;
	}

	public void setBtnLimpar(JButton btnLimpar) {
		this.btnLimpar = btnLimpar;
	}

}
