package dao;

import modelo.Lista;
import modelo.Paciente;

public class PacienteDao {

	public boolean cadastrarPaciente(Paciente pac){
		
		Lista listaCad = new Lista();
		
		listaCad.addPaciente(pac);
		
		return true;
	}
	
}
